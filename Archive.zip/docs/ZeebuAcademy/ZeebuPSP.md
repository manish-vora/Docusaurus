---
id: zeebupsp
title: Zeebu PSP
slug: /zeebuacademy/zeebupsp
sidebar_label: Zeebu PSP
sidebar_position: 2
hide_title: true
---
<h2> Zeebu PSP </h2>

<img src="https://zeebu-1.gitbook.io/~gitbook/image?url=https%3A%2F%2F2383692467-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FMSQ1YNH06MaNXoWUmrJo%252Fuploads%252FLeTSyXmCwR2rUcYMhpsk%252FZeebu%2520Fee%2520Structure.png%3Falt%3Dmedia%26token%3D26bddda9-d746-470a-ac76-79f2f265471e&width=768&dpr=4&quality=100&sign=e5a19887&sv=2" alt="Zeebu Whitepaper Diagram" width="1000" />

### Merchants

Merchants are telecom companies that process and route calls through their networks. They initiate transactions on the Zeebu network by raising invoices for the services they provide. Merchants pay a 1% fee on the volume processed through the Zeebu network.

**Benefits**:

- Instant settlements, improving cash flow 
- Reduced currency conversion costs 
- Automated reconciliation, minimizing errors 
- Enhanced transparency in transactions

The total fee for each transaction on the Zeebu network is 2% (1% from the merchant and 1% from the customer). This fee structure ensures that both parties contribute equally to the network's operation while still benefiting from significantly reduced costs compared to traditional settlement methods. Giving the rare ability for Zeebu to reward the community involvement with Stablecoins, instead of their native token. Creating an emission-less protocol.

### Customers

Customers are telecom companies that receive terminated calls routed by merchants. They accept and pay invoices for the call termination services provided by merchants. Customers also pay a 1% fee on the volume processed through the Zeebu network.

**Benefits**:

- Real-time payment capabilities 
- Reduced need for prepayments 
- Improved ability to manage credit limits 
- Access to a wider network of service providers

The total fee for each transaction on the Zeebu network is 2% (1% from the merchant and 1% from the customer). This fee structure ensures that both parties contribute equally to the network's operation while still benefiting from significantly reduced costs compared to traditional settlement methods. Giving the rare ability for Zeebu to reward the community involvement with Stablecoins, instead of their native token. Creating an emissionless protocol.