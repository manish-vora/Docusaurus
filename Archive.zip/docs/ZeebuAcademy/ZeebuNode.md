---
id: zeebunode
title: Zeebu Node
slug: /zeebuacademy/zeebunode
sidebar_label: Zeebu Node
sidebar_position: 3
hide_title: true
---
<h2> Zeebu Node </h2>

Zeebu's innovative node activation process is the cornerstone of its network expansion strategy. This two-stage approach – Pre-live and Live nodes – creates a pathway for gradual, sustainable growth while offering compelling incentives for early adopters and community engagement.

### Why Run a Zeebu Node?

1. Influence and Impact: As a node operator, you'll play a crucial role in shaping the future of telecom settlements. Your node will directly contribute to processing transactions and maintaining network integrity.

2. Portfolio Diversity: Running a Zeebu node offers a unique opportunity to diversify your crypto portfolio beyond traditional assets. It's a chance to be part of a groundbreaking project in the telecom-blockchain intersection.

3. Real-World Rewards: Unlike many protocols, Zeebu nodes generate rewards from actual telecom transactions. 

4. Community Building: Your node becomes a focal point for your community. As delegators stake to your node, you're not just earning rewards – you're building a dedicated following within the Zeebu ecosystem.

### Getting Started

1. **Access the Node Dashboard**: Visit the Zeebu website and navigate to the Node Dashboard.
2. **Connect Your Web3 Wallet**: Ensure you're using a compatible wallet to interact with the Zeebu platform.
3. **KYC/KYB Process**: Complete the necessary Know Your Customer/Know Your Business verification steps.
4. **Approval**: Once verified, Zeebu will review and approve your application.
5. **Node Initiation**: Upon approval, you can initiate your node directly from the dashboard.

### After Successful KYC/KYB

1. Upon successfully completing the KYC/KYB process, click "Go to Dashboard".

<img src="https://zeebu-1.gitbook.io/~gitbook/image?url=https%3A%2F%2F2383692467-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FMSQ1YNH06MaNXoWUmrJo%252Fuploads%252Fkiilmr08Er0Ba9G6NAai%252Fimage.png%3Falt%3Dmedia%26token%3D82d03746-c46a-4608-8b17-06281470ee2d&width=400&dpr=3&quality=100&sign=678d35b7&sv=2" width="1000" />

2. Select the chain on which you want to deploy the On-chain clearing house Smart contract

<img src="https://zeebu-1.gitbook.io/~gitbook/image?url=https%3A%2F%2F2383692467-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FMSQ1YNH06MaNXoWUmrJo%252Fuploads%252FxeFAByPzEUvrxyS676ra%252Fimage.png%3Falt%3Dmedia%26token%3D6948df11-ba17-4480-aafa-1bed6ea22bd7&width=400&dpr=3&quality=100&sign=87731f89&sv=2" width="1000" />

3. Make sure you have ETH(base) available in you wallet for paying the GAS fees

4. Choose the type of On-chain house smart contract you want to deploy

<img src="https://zeebu-1.gitbook.io/~gitbook/image?url=https%3A%2F%2F2383692467-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FMSQ1YNH06MaNXoWUmrJo%252Fuploads%252FF6qt3qgF9krwKCY3m32G%252Fimage.png%3Falt%3Dmedia%26token%3D987eb357-4e1a-4f7e-b9ea-1e167b5f2b08&width=400&dpr=3&quality=100&sign=e2bb2487&sv=2" width="1000" />

5. Click "Deploy Node Now"

<img src="https://zeebu-1.gitbook.io/~gitbook/image?url=https%3A%2F%2F2383692467-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FMSQ1YNH06MaNXoWUmrJo%252Fuploads%252FYZwhNxjqVriA8RosF0zn%252Fimage.png%3Falt%3Dmedia%26token%3D768e1698-d774-4d47-b9d6-e903a2ad425c&width=400&dpr=3&quality=100&sign=1f5c6bb8&sv=2" width="1000" />

6. Approve transaction in your wallet

7. Click "Activate Node"

<img src="https://zeebu-1.gitbook.io/~gitbook/image?url=https%3A%2F%2F2383692467-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FMSQ1YNH06MaNXoWUmrJo%252Fuploads%252FAuSHQmJqrC6badOPKhrW%252Fimage.png%3Falt%3Dmedia%26token%3D56f830c8-4512-414d-8524-3e5d9ed03be1&width=400&dpr=3&quality=100&sign=cd4fd0c4&sv=2" width="1000" />

8. Click "Execute Your Node"

<img src="https://zeebu-1.gitbook.io/~gitbook/image?url=https%3A%2F%2F2383692467-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FMSQ1YNH06MaNXoWUmrJo%252Fuploads%252FAHiHAx6zQq65tk1QKB8f%252Fimage.png%3Falt%3Dmedia%26token%3Df7e969b2-bb6d-4d26-8da3-b410f57c7cf0&width=400&dpr=3&quality=100&sign=e2eda390&sv=2" width="1000" />

9. Approve transaction in your wallet

10. Click "Submit Your Node"

<img src="https://zeebu-1.gitbook.io/~gitbook/image?url=https%3A%2F%2F2383692467-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FMSQ1YNH06MaNXoWUmrJo%252Fuploads%252FM6HAYKd42HbaPLTp2O66%252Fimage.png%3Falt%3Dmedia%26token%3D96d17796-e99d-4c87-b470-7b1df0b3486c&width=400&dpr=3&quality=100&sign=957f9b05&sv=2" width="1000" />

11. Approve transaction in your wallet

12. Click "Submit Your Contract's"

<img src="https://zeebu-1.gitbook.io/~gitbook/image?url=https%3A%2F%2F2383692467-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FMSQ1YNH06MaNXoWUmrJo%252Fuploads%252FgXdv6X0DUgdGK1nZRAgq%252Fimage.png%3Falt%3Dmedia%26token%3D9ec91d78-fe37-4e56-ae1c-654551d68fab&width=400&dpr=3&quality=100&sign=2bcec40d&sv=2" width="1000" />

13. Upon successful submission you will see the screen for "waiting for admin approval"

<img src="https://zeebu-1.gitbook.io/~gitbook/image?url=https%3A%2F%2F2383692467-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FMSQ1YNH06MaNXoWUmrJo%252Fuploads%252FxDzZCQiWeaj5PMITQWEF%252Fimage.png%3Falt%3Dmedia%26token%3Db0cf5eef-cbfd-4db1-bd66-30833dc1ca2e&width=400&dpr=3&quality=100&sign=8ed664de&sv=2" width="1000" />

14. Zeebu Foundation will review your node details and approve/reject based on the internal screening criteria

Congraulations! You have successfully applied to become a Zeebu Deployer. 

### Node Staking Breakdown

<img src="https://zeebu-1.gitbook.io/~gitbook/image?url=https%3A%2F%2F2383692467-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FMSQ1YNH06MaNXoWUmrJo%252Fuploads%252FN3YxEvjZUXcHTRQkp47C%252FNode%2520Breakdown.png%3Falt%3Dmedia%26token%3D151d7481-f2b0-4550-b035-aad76a1bc762&width=400&dpr=3&quality=100&sign=9a2a3608&sv=2" width="1000" />

### Pre-Live Node State

When you first activate your node, it enters the Pre-Live state. This is a crucial phase for building momentum:

    - **Base APY**: Pre-Live nodes offer a base APY of 25% to delegators, derived from providing the active service of staking their ZBU tokens to the network, incentivizing early staking.

    - **Community Building**: Use this phase to educate your audience about Zeebu and encourage delegation.

    - **Preparation for Live Status**: Work towards accumulating 200,000 ZBU in delegations to transition to Live status.

For a detailed breakdown of the Pre-Live state and its benefits, visit our Pre-Live Node page.

### Transitioning to Live Node

Once your node accumulates 200,000 ZBU in delegations, it becomes eligible for Live status. Live nodes process actual transactions and earn rewards based on network activity. Learn more about the opportunities and responsibilities of Live nodes on our Live Node page.

Are You a KOL Interested in Running a Zeebu Node?

If you're a Key Opinion Leader in the crypto space and believe you'd be a good fit for this opportunity, we want to hear from you! Contact our team to discuss how you can join Zeebu's growing network.

Check out our Courseware section for a comprehensive guide on setting up and managing your Zeebu node. This resource provides step-by-step instructions, best practices, and answers to frequently asked questions.

Join Zeebu in revolutionizing telecom settlements. Activate your node today and be at the forefront of this groundbreaking ecosystem!