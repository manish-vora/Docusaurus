---
id: zeebuairdrop
title: Zeebu Airdrop
slug: /zeebuacademy/zeebuairdrop
sidebar_label: Zeebu Airdrop
sidebar_position: 4
hide_title: true
---
<h2> Zeebu Airdrop </h2>

### Overview

Our airdrop will consist of four epochs over a period of time that will be announced soon, starting with Epoch 1. This epoch will feature four reward tiers for the campaign: Blue Tier, Silver Tier, Gold Tier, and Platinum Tier.

<img src="https://zeebu-1.gitbook.io/~gitbook/image?url=https%3A%2F%2F2383692467-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FMSQ1YNH06MaNXoWUmrJo%252Fuploads%252FcT4dFutdd7n4oE1nBSo4%252FAirdrop.png%3Falt%3Dmedia%26token%3Df3ea7451-ecee-4534-8854-070b585937e1&width=400&dpr=3&quality=100&sign=a0b4781f&sv=2" width="1000"/>

These tiers serve as the initiation and growth campaign for Zeebu as it advances toward becoming a more decentralized entity, helping to uphold the ethos and principles that have guided Web3 so far.

### Purpose of the ZBU Airdrop

Since its inception in 2023, Zeebu has championed transformative changes within the telecom industry, modernizing outdated payment systems and enhancing blockchain trust in the $120 billion telecom prepayment market. With the **launch of the ZBU Protocol**, Zeebu is driving a comprehensive architectural overhaul to establish a decentralized, distributed, and liquidity-optimized payment infrastructure. This innovative protocol reduces the telecom industry's standard transaction fees from 4-5% to 2% and decreases settlement times, creating an efficient pathway for telecom giants to serve retail markets.

<img src="https://zeebu-1.gitbook.io/~gitbook/image?url=https%3A%2F%2F2383692467-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FMSQ1YNH06MaNXoWUmrJo%252Fuploads%252FDN3VrxfJ2aHPEzEdrFDk%252Fimage.png%3Falt%3Dmedia%26token%3D6e3b0dda-ba73-40f5-96a8-4ee26e5f1be2&width=400&dpr=3&quality=100&sign=d7e4ddde&sv=2" width="1000"/>

### Why ZBU Airdrop is Strategically Essential

The **ZBU Airdrop** is a foundational strategy to ensure fair distribution of tokens across the Zeebu ecosystem. With a total of 60 million ZBU allocated, the airdrop rewards and incentivizes active participants who contribute to the decentralized economy's success. These participants bolster the protocol’s liquidity, contributing to its vision of becoming the largest decentralized liquidity protocol for B2B settlements.

### ZBU Protocol’s Innovative Infrastructure for B2B Use Cases

The ZBU Protocol introduces an advanced infrastructure to address the unique demands of B2B settlements with:

    - **Increased Transparency and High Settlement Throughput**: The protocol leverages transparent, public liquidity pools and an on-chain clearing house powered by smart contracts. This settlement & clearing mechanism ensures transactions get settled with optimal liquidity and minimized slippage. Zeebu processes approximately $25 million worth of settlements daily using ZBU tokens, which will be rampped up with current waitlist merchant upto $100 million a day to achieve the goal of $14 billion in settlement in next 12 months.

    - **Decentralized Governance and Incentive Structure**: Governance is distributed across participants, starting with On-chain clearing house and OLPs powered with delegators providing their ZBU power to support settlement activities within the ecosystem. Delegators play a crucial role in enhancing transaction efficiency and ensuring equitable governance.

### Reward Mechanism for Protocol Contributors

The protocol’s fee structure enables sustainable rewards for its contributors:

    - **On-Chain Clearing House**: Clearing house operators receive upto 30% of the fee value for optimizing transaction settlements.

    - **On-Demand Liquidity Providers (OLPs)**: Liquidity providers receive upto 20% of the fee value, reflecting their essential role in ensuring the availability of liquidity and stability across transactions.

### Goal of the Airdrop

By distributing 60 million ZBU tokens, the airdrop fosters a decentralized, well-distributed ecosystem, supporting the liquidity pool expansion and encouraging greater participation. This model not only ensures fair token allocation but also fuels the protocol’s growth, helping ZBU Protocol achieve its mission of becoming a premier decentralized settlement platform with substantial TVL (Total Value Locked).

***This whole ecosystem-building activity linked Airdrop campaign season 1 will run for earlier of (a) achivement of $1Bn in TVL or (b) till 31st March 2025.***