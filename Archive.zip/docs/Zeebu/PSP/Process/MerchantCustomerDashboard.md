---
id: merchantcustomerdashboard
title: Merchant & Customer Dashboard
slug: /zeebu/psp/process/merchantcustomerdashboard
sidebar_label: Merchant & Customer Dashboard
sidebar_position: 1
hide_title: true
---
<h2> Merchant & Customer Dashboard </h2>

Telecom carriers must have access to all business information in one single view. Zeebu understands that the telecom carrier business is highly operations-intensive, fast-moving, and involves multiple stakeholders for service delivery. Zeebu designed our merchant and customer dashboard with this in mind, creating a bespoke and intuitive dashboard to serve these industry-specific needs. The Zeebu platform provides a single view of all business activities, including customer onboarding, invoice generation, payment, wallet balance, rewards, and token purchase options.

Telecom carriers, as part of the call flow network, act as both merchants and customers concurrently. Revenue inflow to the merchant account and outflow from the customer account could be a sequential or parallel process. Therefore, we provide a single login account so carriers can instantly keep track of both revenue and payables in one view.

<img src="https://zeebu-1.gitbook.io/~gitbook/image?url=https%3A%2F%2F2383692467-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FMSQ1YNH06MaNXoWUmrJo%252Fuploads%252FEAmcuyfiKN5HHRZAPiTY%252FPSP.webp%3Falt%3Dmedia%26token%3Db759e3c7-9fa4-49b7-9edd-aedd02a7574d&width=400&dpr=3&quality=100&sign=22e9b3a8&sv=2" width="1000" />

Zeebu’s team of experts have deep insights into the legacy systems and processes for managing telecom carrier businesses, and our platform was built with this knowledge. Our dashboards overcome the challenges of legacy systems and offer an easy-to-use interface to allow telecom carriers to be onboarded to the platform with a minimal learning curve. Users will have upfront access to all important features.

Zeebu understands that telecom carriers operate in a fast-paced business environment. Many stakeholders are operating on the go to meet the demands of their global business, so we made sure Zeebu developed a mobile-compatible dashboard to ensure access to important information and tools across devices. Zeebu’s simple, intuitive interface and real-time updates enable business users to run operations effectively any time, anywhere.

In addition to the simplicity and ease of use of the Zeebu platform, users will also earn rewards with every successfully settled transaction. When an invoice is settled between two Zeebu ecosystem partners, both parties receive Zeebu tokens as rewards. Each user can see their reward balance in their dashboards and can use Zeebu tokens to settle future invoices. Users can see their wallet balance in the Zeebu dashboard, with a clear view of their balances in fiat, other stable tokens, and Zeebu tokens.