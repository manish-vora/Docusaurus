---
id: paymentprocessorsettlement
title: Payment Processor & Settlement Layer
slug: /zeebu/psp/process/paymentprocessorsettlement
sidebar_label: Payment Processor & Settlement Layer
sidebar_position: 2
hide_title: true
---
<h2> Payment Processor & Settlement Layer </h2>

Zeebu is an end-to-end solution that enables instant, secure settlements for global telecom carriers powered by regularly audited smart contracts. Zeebu’s platform runs on the Binance Smart Chain (BSC). Our solution is comprised of four technology layers:

<img src="https://zeebu-1.gitbook.io/~gitbook/image?url=https%3A%2F%2F2383692467-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FMSQ1YNH06MaNXoWUmrJo%252Fuploads%252FYu0Un9f77cFr822kzGqt%252FScreenshot%25202024-12-18%2520at%252012.48.07%25E2%2580%25AFPM.png%3Falt%3Dmedia%26token%3D140f4c93-4efb-4235-876c-1c294d2d9b7b&width=400&dpr=3&quality=100&sign=2097895b&sv=2" width="600" />

UI/UX layer for customers and merchants

<img src="https://zeebu-1.gitbook.io/~gitbook/image?url=https%3A%2F%2F2383692467-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FMSQ1YNH06MaNXoWUmrJo%252Fuploads%252FwlDfmprcp5ZaF59qY3xX%252FScreenshot%25202024-12-18%2520at%252012.48.57%25E2%2580%25AFPM.png%3Falt%3Dmedia%26token%3D9a4dc797-5f94-41aa-adf2-ecd54c94c0a3&width=400&dpr=3&quality=100&sign=548aa00c&sv=2" width="600" />

A carefully crafted application on React and Javascript bridging the best of Web2 and Web3 to ensure that the experience is intuitive, efficient, and effective.

### Payment Processing and Invoice Settlement

**PSP layer for payment processing and invoice settlement, which are KYC and AML compliant**

Designed for convenience, helps users manage their digital assets, make transactions, and receive funds from anywhere in the world. Powered by multi-sig technology to ensure your funds are safe and secure

Integrating lightning-fast and secure high-frequency trades for all crypto pairs, with best in class gateway technology built on python, advanced security measures like SoC2 and a user-friendly interface.

Partnership with leading KYC/AML agencies for best practices in compliance. Giving confidence to users to enjoy fast and secure transactions while complying with regulatory requirements.

Enabling invoice raising and settlement product partnerships to offers secure and streamlined payment processes for all telecom merchants, with efficient settlement times and an intuitive interface.

### Blockchain Layer Decentralized and Transparent Manner

**Blockchain layer, which handles on-chain asset settlement in a decentralized and transparent manner**

Zeebu on-chain asset settlement feature empowers users with ETH blockchain security and transparency, allowing them to settle transactions directly on the blockchain. Enjoy complete control and ownership over your assets with our user-friendly platform.

Powering the ecosystem of Zeebu are OpenZeppelin smart contracts built on ERC20 to facilitate seamless invoice settlements in a decentralized and transparent manner. This ensures that transactions are tamper-proof and free from any unauthorized modifications, offering high security.

<img src="https://zeebu-1.gitbook.io/~gitbook/image?url=https%3A%2F%2F2383692467-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FMSQ1YNH06MaNXoWUmrJo%252Fuploads%252FL1KiBoVUpUJcxcJZ4Zy7%252FScreenshot%25202024-12-18%2520at%252012.51.37%25E2%2580%25AFPM.png%3Falt%3Dmedia%26token%3D5061d6b4-616a-459a-8d5c-855c63946997&width=400&dpr=3&quality=100&sign=f45209fd&sv=2" width="600" />

Back-end Layer, which is responsible for databasing, single sign on, and task automation

<img src="https://zeebu-1.gitbook.io/~gitbook/image?url=https%3A%2F%2F2383692467-files.gitbook.io%2F%7E%2Ffiles%2Fv0%2Fb%2Fgitbook-x-prod.appspot.com%2Fo%2Fspaces%252FMSQ1YNH06MaNXoWUmrJo%252Fuploads%252FSW4PBe5wkMu0hlli5B2g%252FScreenshot%25202024-12-18%2520at%252012.51.08%25E2%2580%25AFPM.png%3Falt%3Dmedia%26token%3Da0e155e2-9a0f-4318-8fd3-2a4f546c4e45&width=400&dpr=3&quality=100&sign=21a3eb3b&sv=2" width="600" />